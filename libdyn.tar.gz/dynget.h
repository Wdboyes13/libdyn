#pragma once
char* getstr(const char* prompt);